import React, { useEffect, useRef, useState } from 'react';
import { Inspector } from '../components/inspector';
import { XYInterface } from '../components/interfaces';
import { MainToolbar } from '../components/mainToolbar';
import { Square } from '../components/square';
import { Tools } from '../components/tools';
import { useWindowSize } from '../hooks/useWindowSize';
import gridImageBg from '../images/grid.svg';
import '../scss/index.scss';

interface ControlsInterface {
  view: { x: number, y: number, zoom: number };
  viewPos: { prevX: number | null, prevY: number | null, isDragging: boolean };
}
const Home: React.FC = () => {
  console.log('fire')
  const canvasRef = useRef<HTMLCanvasElement>(null);
  let canvas: HTMLCanvasElement | null;
  let ctx: CanvasRenderingContext2D | null;
  let canvasImage: HTMLImageElement;
  let gridPatternBackground: CanvasPattern | null;
  const windowSize = useWindowSize();
  const controls: ControlsInterface = {
      view: { x: 0, y: 0, zoom: 1 },
      viewPos: { prevX: null, prevY: null, isDragging: false },
    };
  const dragBg = true;
  let width: number;
  let height: number;
  const [state, setState] = useState(1);

  const setupCanvas = () => {
    width = window.innerWidth - 540;
    height = window.innerHeight - 139;
    if (!canvas) canvas = canvasRef.current;
    if (canvas) canvas.width = width;
    if (canvas) canvas.height = height;
    if (!ctx && canvas) ctx = canvas.getContext('2d');
    if (ctx && canvasImage) {
      gridPatternBackground = ctx.createPattern(canvasImage, 'repeat');
      draw();
    }
    if (ctx && !canvasImage) {
      const img = new Image();
      img.src = gridImageBg;
      img.onload = () => {
        canvasImage = img;
        if (ctx) {
          gridPatternBackground = ctx.createPattern(canvasImage, 'repeat');
        }
        draw();
      };
    }
  };

  useEffect(() => {

    if (!canvas) setupCanvas();
  }, [windowSize]);

  const setMouseDown = (event: React.MouseEvent) => {
    const x = event.nativeEvent.offsetX;
    const y = event.nativeEvent.offsetY;
    if (canvas) canvas.style.cursor = 'grab';
    controls.viewPos.isDragging = true;
    controls.viewPos.prevX = x;
    controls.viewPos.prevY = y;
  };

  const setMouseUp = (event: React.MouseEvent) => {
    if (canvas) canvas.style.cursor = 'crosshair';
    controls.viewPos.isDragging = false;
    controls.viewPos.prevX = null;
    controls.viewPos.prevY = null;
  };

  const setMouseMove = (event: React.MouseEvent) => {
    if (!canvas) setupCanvas();
    const x = event.nativeEvent.offsetX;
    const y = event.nativeEvent.offsetY;
    const controlsView = controls.view;
    const zoom = controls.view.zoom;
    // if (selectedNode) {
    //   selectedNode.updatePosition({
    //     x: (x - controlsView.x - (selectedNode.size.x / 2) * zoom) / zoom,
    //     y: (y - controlsView.y - (selectedNode.size.y / 2) * zoom) / zoom,
    //   });
    // }
    if (controls.viewPos.isDragging && dragBg) setPan(event.nativeEvent);
    if (controls.viewPos.isDragging && !dragBg) setMove(event.nativeEvent);
    draw();
  };

  const setPan = (event: MouseEvent) => {
    const x = event.offsetX;
    const y = event.offsetY;
    let dx;
    let dy;
    if (canvas) canvas.style.cursor = 'grab';
    if (controls.viewPos.prevX) dx = x - controls.viewPos.prevX;
    if (controls.viewPos.prevY) dy = y - controls.viewPos.prevY;
    if (controls.viewPos.prevX || controls.viewPos.prevY) {
      if (dx) controls.view.x += dx;
      if (dy) controls.view.y += dy;
      controls.viewPos.prevX = x;
      controls.viewPos.prevY = y;
    }
    draw();
  };

  const setMove = (event: MouseEvent) => {
    const x = event.offsetX;
    const y = event.offsetY;
    const controlsView = controls.view;
    const zoom = controls.view.zoom;
    // if (selectedNode) {
    //   selectedNode.updatePosition({
    //     x: (x - controlsView.x - (selectedNode.size.x / 2) * zoom) / zoom,
    //     y: (y - controlsView.y - (selectedNode.size.y / 2) * zoom) / zoom,
    //   });
    // }
    draw();
  };

  const setZoom = (event: React.WheelEvent) => {
    const x = event.nativeEvent.offsetX;
    const y = event.nativeEvent.offsetY;
    const { deltaY } = event;
    const weigthed = { x: 0, y: 0 };
    const direction = deltaY > 0 ? -1 : 1;
    if (direction === 1 && canvas) canvas.style.cursor = 'zoom-in';
    if (direction === -1 && canvas) canvas.style.cursor = 'zoom-out';
    const factor = 0.05;
    const zoom = direction * factor;
    if (controls.view.zoom + zoom < 3 && controls.view.zoom + zoom > 0.8) {
      weigthed.x = (x - controls.view.x) / (width * controls.view.zoom);
      weigthed.y = (y - controls.view.y) / (height * controls.view.zoom);
      controls.view.x -= weigthed.x * width * zoom;
      controls.view.y -= weigthed.y * height * zoom;
      controls.view.zoom += zoom;
      draw();
    }
  };

  const draw = () => {
    const paint = () => {
      if (canvas && ctx && gridPatternBackground) {
        ctx.clearRect(0, 0, Math.floor(width), Math.floor(height));
        ctx.save();
        ctx.translate(Math.floor(controls.view.x), Math.floor(controls.view.y));
        ctx.scale(controls.view.zoom, controls.view.zoom);
        ctx.rect(0, 0, Math.floor(width), Math.floor(height));
        if (gridPatternBackground) ctx.fillStyle = gridPatternBackground;
        if (gridPatternBackground) ctx.fill();
        //this.nodeObjects.forEach((object) => object.draw(ctx));
        ctx.restore();
      }
    };
    requestAnimationFrame(paint);
  };

  return (
    <div className='container'>
      <div className='container--main-toolbar'>
        <MainToolbar />
      </div>
      <div className='container--center'>
        <div className='container--tools'>
          <Tools />
        </div>
        <div className='container--canvas'>
          <canvas
            id='canvas'
            ref={canvasRef}
            className='canvas'
            onMouseDown={(e: React.MouseEvent) => setMouseDown(e)}
            onMouseUp={(e: React.MouseEvent) => setMouseUp(e)}
            onMouseMove={(e: React.MouseEvent) => setMouseMove(e)}
            onWheel={(e: React.WheelEvent) => setZoom(e)}
          />
        </div>
        <div className='container--inspector'>
          <Inspector />
        </div>
      </div>
      <div className='container--footer'></div>
    </div>
  );
};

export { Home };
