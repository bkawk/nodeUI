import React from 'react';

const NotFound: React.FC = () => {
  return (
  <div>notFound</div>
  );
};

export { NotFound };
