import { createContext } from 'react';
import { XYInterface } from './components/interfaces';
import { Square } from './components/square';

interface ActionInterface {
  type: string;
  value: string | boolean | object | CanvasRenderingContext2D | CanvasPattern;
}

interface NodeInterface {
  name: string;
  mainToolbarIcon: string;
}

export interface ControlInterface {
  view: { x: number; y: number; zoom: number };
  viewPos: {
    prevX: number | null;
    prevY: number | null;
    isDragging: boolean;
  };
}

const Dispatch = createContext({
  dispatch: (action: ActionInterface) => {
    //
  },
});

interface StateInterface {
  canvas: {
    canvasSize: XYInterface;
    controls: ControlInterface;
    mouseDown: boolean;
    mousePosition: XYInterface;
    panLock: boolean;
  };
  ui: {
    mainToolbar: { [key: string]: NodeInterface[] };
  };
}

const InitialState: StateInterface = {
  canvas: {
    canvasSize: { x: window.innerWidth - 540, y: window.innerHeight - 130 },
    controls: {
      view: { x: 0, y: 0, zoom: 1 },
      viewPos: { prevX: null, prevY: null, isDragging: false },
    },
    mouseDown: false,
    mousePosition: { x: 0, y: 0 },
    panLock: false,
  },
  ui: {
    mainToolbar: {
      data: [],
      shapes: [],
    },
  },
};

const Global = createContext({
  global: InitialState,
});

const SET_MOUSE_DOWN = 'SET_MOUSE_DOWN';
const SET_PAN_LOCK = 'SET_PAN_LOCK';
const SET_MOUSE_POSITION = 'SET_MOUSE_POSITION';
const SET_CANVAS_SIZE = 'SET_CANVAS_SIZE';
const SET_MAIN_TOOLBAR = 'SET_MAIN_TOOLBAR';

// tslint:disable-next-line: no-any
const Reducer = (state: StateInterface, action: any) => {
  switch (action.type) {
    case 'SET_MOUSE_DOWN':
      return {
        ...state,
        canvas: { ...state.canvas, mouseDown: action.value },
      };
    case 'SET_PAN_LOCK':
      return {
        ...state,
        canvas: { ...state.canvas, panLock: action.value },
      };
    case 'SET_MOUSE_POSITION':
      return {
        ...state,
        canvas: { ...state.canvas, mousePosition: action.value },
      };
    case 'SET_CANVAS_SIZE':
      return {
        ...state,
        canvas: { ...state.canvas, canvasSize: action.value },
      };
    case 'SET_MAIN_TOOLBAR':
      return {
        ...state,
        ui: { ...state.ui, mainToolbar: action.value },
      };
    default:
      return state;
  }
};

export {
  Dispatch,
  Global,
  InitialState,
  Reducer,
  SET_MAIN_TOOLBAR,
  SET_MOUSE_DOWN,
  SET_PAN_LOCK,
  SET_MOUSE_POSITION,
  SET_CANVAS_SIZE,
};
